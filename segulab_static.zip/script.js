// ============ ICONOS ============
if (window.lucide) { lucide.createIcons(); }

// ============ NAVEGACIÓN ENTRE SECCIONES ============
const navButtons = document.querySelectorAll('.nav-btn');
const panels = document.querySelectorAll('.section-panel');
const mainNav = document.getElementById('mainNav');
const menuToggle = document.getElementById('menuToggle');

function activateSection(sectionId) {
  navButtons.forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.section === sectionId);
  });
  panels.forEach((panel) => {
    panel.classList.toggle('active', panel.id === `section-${sectionId}`);
  });
  const headerHeight = 120;
  const target = document.getElementById(`section-${sectionId}`);
  if (target) {
    const top = target.getBoundingClientRect().top + window.scrollY - headerHeight;
    window.scrollTo({ top, behavior: 'smooth' });
  }
}

navButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    activateSection(btn.dataset.section);
    mainNav.classList.remove('open');
  });
});

menuToggle.addEventListener('click', () => {
  mainNav.classList.toggle('open');
});

// ============ PATRÓN DECORATIVO DEL HERO (retícula + anillos) ============
function heroPatternSVG(variant) {
  const palettes = {
    primary: { from: '#0F1A68', to: '#1D34D1' },
    mustard: { from: '#974B0C', to: '#CD6711' },
    green:   { from: '#1f5a3d', to: '#2c7350' },
  };
  const c = palettes[variant] || palettes.primary;
  const id = 'dots-' + variant;
  return `
    <div style="position:absolute;inset:0;background:linear-gradient(120deg, ${c.from}, ${c.to});">
      <svg style="position:absolute;inset:0;width:100%;height:100%;" preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="${id}" width="26" height="26" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.3" fill="rgba(255,255,255,0.14)" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#${id})" />
        <circle cx="88%" cy="20%" r="60" fill="none" stroke="rgba(255,255,255,0.10)" stroke-width="1.5" />
        <circle cx="88%" cy="20%" r="110" fill="none" stroke="rgba(255,255,255,0.10)" stroke-width="1.5" />
        <circle cx="88%" cy="20%" r="160" fill="none" stroke="rgba(255,255,255,0.10)" stroke-width="1.5" />
        <circle cx="6%" cy="92%" r="45" fill="none" stroke="rgba(255,255,255,0.10)" stroke-width="1.5" />
        <circle cx="6%" cy="92%" r="85" fill="none" stroke="rgba(255,255,255,0.10)" stroke-width="1.5" />
      </svg>
    </div>`;
}

document.getElementById('hero-pattern-1').innerHTML = heroPatternSVG('primary');
document.getElementById('hero-pattern-2').innerHTML = heroPatternSVG('primary');
document.getElementById('hero-pattern-3').innerHTML = heroPatternSVG('primary');
document.getElementById('hero-pattern-4').innerHTML = heroPatternSVG('mustard');
document.getElementById('hero-pattern-5').innerHTML = heroPatternSVG('green');

// ============ ANIMAR BARRAS DE PERCEPCIÓN DE INSEGURIDAD ============
const bars = document.querySelectorAll('.bar-fill');
const barObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      const el = entry.target;
      el.style.width = el.dataset.pct + '%';
      barObserver.unobserve(el);
    }
  });
}, { threshold: 0.3 });
bars.forEach((b) => barObserver.observe(b));

// ============ REVEAL AL HACER SCROLL ============
const revealTargets = document.querySelectorAll('.card, .pillar-card, .kpi-card, .phase-row, .level-card, .actor-card, .box, .map-wrap');
revealTargets.forEach((el) => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(14px)';
  el.style.transition = 'opacity .5s ease, transform .5s ease';
});
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
revealTargets.forEach((el) => revealObserver.observe(el));

// ============ CHATBOT ============
const chatFab = document.getElementById('chatFab');
const chatWindow = document.getElementById('chatWindow');
const chatClose = document.getElementById('chatClose');
const chatBody = document.getElementById('chatBody');
const chatInput = document.getElementById('chatInput');
const chatSend = document.getElementById('chatSend');

function addMessage(text, sender) {
  const msg = document.createElement('div');
  msg.className = `msg ${sender}`;
  msg.textContent = text;
  chatBody.appendChild(msg);
  chatBody.scrollTop = chatBody.scrollHeight;
}

addMessage('¡Hola! Soy tu asistente del SEGULAB. ¿Tienes alguna pregunta sobre el laboratorio de seguridad ciudadana?', 'bot');

function generateBotResponse(userInput) {
  const input = userInput.toLowerCase();

  if (input.includes('qué es') || input.includes('definición') || input.includes('segulab')) {
    return 'El SEGULAB es un sistema dinámico de registro para medir y correlacionar variables de seguridad personal, urbana y comunitaria en una zona poblacional específica. Es una respuesta fundamentada en evidencia internacional que reconoce que la participación ciudadana en seguridad incide directamente en la percepción de inseguridad.';
  }
  if (input.includes('pilares') || input.includes('pilar')) {
    return 'El SEGULAB se basa en tres pilares fundamentales:\n\n1. Enfoque de laboratorio - Experimentación controlada y aprendizaje continuo\n2. Ciencia de datos aplicada - Cuatro componentes tecnológicos integrados (SIG, Observatorio, Alerta temprana, Visualización)\n3. Gestión del cambio - Cuatro estrategias para transformar prácticas institucionales y comunitarias';
  }
  if (input.includes('ciclo') || input.includes('implementación') || input.includes('fases')) {
    return 'El ciclo de implementación del SEGULAB tiene 5 fases:\n\n1. Diagnóstico - Análisis del contexto territorial\n2. Diseño - Definición de estrategias y soluciones\n3. Implementación - Ejecución de intervenciones\n4. Monitoreo - Seguimiento y evaluación continua\n5. Sostenibilidad - Institucionalización del laboratorio';
  }
  if (input.includes('actores') || input.includes('actor')) {
    return 'El SEGULAB funciona con seis tipos de actores:\n\n1. Gobierno municipal\n2. Gobierno estatal\n3. Academia\n4. Comunidad\n5. Consejo consultivo ciudadano\n6. Sector privado y OSC\n\nCada actor juega un rol fundamental en el éxito del laboratorio.';
  }
  if (input.includes('contexto') || input.includes('jalisco')) {
    return 'Jalisco enfrenta desafíos significativos de seguridad con concentración delictiva en municipios específicos. El SEGULAB se implementa como respuesta a estos problemas, promoviendo participación ciudadana y enfoque preventivo en territorios priorizados.';
  }
  if (input.includes('indicadores') || input.includes('éxito')) {
    return 'El SEGULAB mide su impacto a través de tres niveles de indicadores:\n\n1. Indicadores de proceso - Miden la ejecución del SEGULAB en el territorio\n2. Indicadores de resultado - Cambios en comportamientos y prácticas\n3. Indicadores de impacto - Transformación en percepción de seguridad y confianza institucional';
  }
  if (input.includes('tecnología') || input.includes('datos') || input.includes('sig')) {
    return 'El SEGULAB integra cuatro componentes tecnológicos:\n\n1. Sistema de información georreferenciada (SIG) - Visualiza distribución espacial de delitos\n2. Observatorio de seguridad - Integra datos de múltiples fuentes\n3. Sistema de alerta temprana - Identifica cambios en patrones\n4. Visualización interactiva - Facilita comprensión y apropiación de información';
  }
  if (input.includes('participación') || input.includes('comunidad') || input.includes('ciudadana')) {
    return 'La participación ciudadana es central en el SEGULAB. Se promueve a través de:\n\n• Grupos focales y talleres participativos\n• Asambleas de validación\n• Consejo consultivo ciudadano elegido democráticamente\n• Sensibilización comunitaria\n• Desarrollo de capacidades locales';
  }
  return 'No tengo información específica sobre eso. Puedo ayudarte con preguntas sobre: qué es el SEGULAB, los 3 pilares, el ciclo de implementación, actores involucrados, contexto en Jalisco, indicadores de éxito, tecnología y participación ciudadana. ¿Hay algo más en lo que pueda ayudarte?';
}

function sendMessage() {
  const value = chatInput.value.trim();
  if (!value) return;
  addMessage(value, 'user');
  chatInput.value = '';
  setTimeout(() => addMessage(generateBotResponse(value), 'bot'), 500);
}

chatFab.addEventListener('click', () => chatWindow.classList.toggle('open'));
chatClose.addEventListener('click', () => chatWindow.classList.remove('open'));
chatSend.addEventListener('click', sendMessage);
chatInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') sendMessage();
});
